/*
 * @Author: greatpie
 * @Date: 2021-07-12 15:29:27
 * @LastEditTime: 2021-07-12 15:30:46
 * @LastEditors: greatpie
 * @FilePath: /alanysis-tool-electron/src/content-manager.js
 */
import React from 'react'

export const StatContext = React.createContext(null)
